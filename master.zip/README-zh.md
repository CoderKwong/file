# 前置条件
1. `conf/nginx/woo.conf`里面的nginx端口设置和域名设置

# 安装

1. `域名/install.php` 根据提示进行安装
2. 创建数据库`redcap`(注意，如果mysql不能启动，大概率是权限问题，请尝试使用sudo)
3. 在`database.php`设置链接数据库账号密码,以及`$salt`值
4. 设置邮件服务 以及`upload_max_filesize`，在`php.ini`文件中，查阅网址： https://www.php.net/manual/en/mail.configuration.php
5. 设置cron job地址 http://localhost/redcap_v9.8.5/ControlCenter/cron_jobs.php

# sendmail配置
1. 域名需要修改docker-compose 配置的hostname，以及 `conf/php.ini`的名字和邮箱地址
2. 每次启动需要进入php的镜像里面启动sendmail服务：`service sendmail start`

