-- Update the timezone
SET GLOBAL time_zone = 'America/Los_Angeles';