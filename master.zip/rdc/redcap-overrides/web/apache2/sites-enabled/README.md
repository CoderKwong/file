# How To
To use the existing 'default' vhost, do not use this directory, but rather 
add your content to the conf-vhost directory.

If, on the other hand, you want to support multiple vhosts, you could add additoinal entries here.