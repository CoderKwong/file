#!/usr/bin/env bash

echo 'Enabling mod rewrite'
a2enmod rewrite
