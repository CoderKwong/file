#!/usr/bin/env bash

echo 'Enabling apache proxy'
a2enmod proxy_http
