<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/

// Call config file
require_once dirname(dirname(__FILE__)) . '/Config/init_global.php';

// Display all REDCap Plugin documentation
PluginDocs::displayPluginMethods();