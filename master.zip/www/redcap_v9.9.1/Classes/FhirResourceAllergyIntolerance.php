<?php
namespace
{

    class FhirResourceAllergyIntolerance extends FhirResourceEntry
    {

        /**
         * name of the endpoint
         */
        const RESOURCE_NAME = 'AllergyIntolerance';

        /** 
         * Map the FHIR endpoint category to the name of the query string "code" parameter.
         * Note: Most categories do not have this structure.
         */
        const DATE_PARAMETER_NAME = 'onset';
        
        /**
         * substance
         *
         * @var \FhirResourceAllergyIntolerance\Substance
         */
        private $substance;
        /**
         * reactions
         *
         * @var \FhirResourceAllergyIntolerance\Reaction[]
         */
        private $reactions = array();
        /**
         * codings
         *
         * @var FhirResourceCoding[]
         */
        private $codings = array();

        /**
         * attribute that contains the date for the resource entry
         *
         * @var string
         */
        protected static $dateAttribute = 'recordedDate';

        public function __construct($params)
        {
            parent::__construct($params);
            $this->substance = $this->setSubstance();
            $this->reactions = $this->setReactions();
            $this->codings = $this->setCodings();
        }

        public function getSubstance()
        {
            return $this->substance;
        }

        protected function setSubstance()
        {
            $substance = new \FhirResourceAllergyIntolerance\Substance($this->substance);
            return $substance;
        }

        public function getReactions()
        {
            return $this->reactions;
        }

        protected function setReactions()
        {
            $reactions = array_map(function($params) {
                return new \FhirResourceAllergyIntolerance\Reaction($params);
            }, $this->search('reaction'));
            if(!is_array($reactions)) $reactions = array();
            return $reactions;
        }

        public function getCodings()
        {
            return $this->codings;
        }

        public function setCodings()
        {
            $codings_groups = array(
                'instance' => $this->search('code.coding[]'),
                'substance' => $this->search('substance.coding[]'),
                'reaction_substance' => $this->search('reaction[].substance.coding[]'),
                'reaction_manifestation' => $this->search('reaction[].manifestation[].coding[]'),
            );
            $all_codings = array();
            foreach($codings_groups as $codings)
            {
                foreach ($codings as $params) {
                    $all_codings[] = new FhirResourceCoding($params);
                }
            }
            return $all_codings;
        }

        /**
         * get the substance coding of a specific system
         *
         * @param string $system
         * @return FhirResourceCoding|null
         */
        public function getSubstanceByCodingSystem($system)
        {
            if(!$this->substance) return;
            $codings = $this->substance->codings;
            foreach ($codings as $coding) {
                if($coding->getSystem()==$system) return $coding;
            }
            return;
        }

        /**
         * parse all codings available in the resource for
         * a specific standard
         *
         * @param string $system
         * @return FhirResourceCoding[]
         */
        public function getCodingsByStandard($standard)
        {
            if(empty($standard)) return;
            $codings = $this->codings;
            $results = array();
            foreach($codings as $coding)
            {
                $current_standard = $coding->getStandard();
                if($current_standard==$standard) $results[] = $coding;
            }
            return $results;
        }

        /**
         * create a long text version of the allergies using
         * all codes found inside the resource
         * codes can be found in:
         * - code.coding[]
         * - substance.coding[]
         * - reaction[].substance.coding[]
         * - reaction[].manifestation[].coding[]
         *
         * @return void
         */
        public function getLongText()
        {
            $codings = $this->codings;
            $text_list = array();
            foreach($codings as $coding)
            {
                $text = $coding->getDisplay();
                $standard = $coding->getStandard();
                $code = $coding->code;
                if($code_text = trim("$standard $code")) $text .= sprintf(" (%s)", $code_text);

                $text_list[] = $text;
            }
            $longText = implode(", ", $text_list);
            if($date = $this->getFormattedDate('Y-m-d')) $longText .= " - ".$date;
            return $longText;
        }

        public function getSubstanceFieldByCodingSystem($system, $key)
        {
            $coding = $this->getSubstanceByCodingSystem($system);
            if($coding) return $coding->{$key};
            return '';
        }
        
        public function getDate()
        {
            $date_string = $this->search(self::$dateAttribute);
            if(empty($date_string)) return '';
            $timestamp = trim(substr($date_string, 0, 10));
            if (strlen($timestamp) == 4) $timestamp .= "-01-01";
            $dateTime =  new DateTime($date_string);
            return $dateTime;
        }

        public function getStatus()
        {
            return $this->search('status');
        }

        public function getData()
        {
            $data = array(
                'status' => $this->getStatus(),
                'date' => $this->getDate(),
                'unii_code' => $this->getSubstanceFieldByCodingSystem(FhirResourceCoding::SYSTEM_FDA_UNII, 'code'),
                'unii_display' => $this->getSubstanceFieldByCodingSystem(FhirResourceCoding::SYSTEM_FDA_UNII, 'display'),
                'ndfrt_code' => $this->getSubstanceFieldByCodingSystem(FhirResourceCoding::SYSTEM_NDF_RT, 'code'),
                'ndfrt_display' => $this->getSubstanceFieldByCodingSystem(FhirResourceCoding::SYSTEM_NDF_RT, 'display'),
                'snomed_code' => $this->getSubstanceFieldByCodingSystem(FhirResourceCoding::SYSTEM_SNOMED_CT, 'code'),
                'snomed_display' => $this->getSubstanceFieldByCodingSystem(FhirResourceCoding::SYSTEM_SNOMED_CT, 'display'),
                'reactions' => $this->reactions,
                'substance' => $this->substance,
                'codings' => $this->codings,
            );
            return $data;
        }

    }
}

namespace FhirResourceAllergyIntolerance
{
    class Substance extends \FhirResource
    { 

        public function __construct($params)
        {
            parent::__construct($params);
            $this->codings = $this->getCodings();
        }

        public function getText()
        {
            return $this->text;
        }

        protected function getCodings()
        {
            $codings = array_map(function($coding) {
                return new \FhirResourceCoding($coding);
            }, $this->coding);
            return $codings;
        }

        public function getData()
        {
            $data = array(
                'text' => $this->getText(),
                'codings' => $this->codings,
            );
            return $data;
        }

        /**
         * get JSON serialized version of the object
         *
         * @return array
         */
        public function jsonSerialize()
        {
            return $this->getData();
        }
    }

    /**
     * @property FhirResourceAllergyIntolerance\Reaction\Manifestation[] $manifestations
     */
    class Reaction extends \FhirResource
    {
        public function __construct($params)
        {
            parent::__construct($params);
            $this->manifestations = $this->getManifestations();
        }

        public function getCertainty()
        {
            return $this->search('certainty');
        }

        /**
         * return the codings for the reaction
         *
         * @return object object with system, code and display values
         */
        protected function getManifestations()
        {
            $manifestations = $this->search('manifestation');
            $manifestation_instance = array();
            foreach ($manifestations as $data) {
                $manifestation_instance[] = new \FhirResourceAllergyIntolerance\Reaction\Manifestation($data);
            };
            return $manifestation_instance;
        }

        public function getData()
        {
            $data = array(
                'certainty' => $this->getCertainty(),
                'manifestations' => $this->getManifestations(),
            );
            return $data;
        }

        /**
         * get JSON serialized version of the object
         *
         * @return array
         */
        public function jsonSerialize()
        {
            return $this->getData();
        }

    }
}
namespace FhirResourceAllergyIntolerance\Reaction
{
    class Manifestation extends \FhirResource
    {
        
    }
}