<?php
namespace {

    /**
     * @property FhirResourceDocumentReference\Attachment[] $attachments
     */
    class FhirResourceDocumentReference extends FhirResourceEntry
    {

        /**
         * name of the endpoint
         */
        const RESOURCE_NAME = 'DocumentReference';

        /** 
         * Map the FHIR endpoint category to the name of the query string "code" parameter.
         * Note: Most categories do not have this structure.
         */
        const DATE_PARAMETER_NAME = 'created';

        // classes for DSTU2
        const CLASS_CCD = '34133-9'; // Summarization of Episode Note
        const CLASS_ENCOUNTER = '11506-3'; // Subsequent Evaluation Note.

        // types for STU3
        const TYPE_DISCHARGE_DOCUMENTATION = '18842-5'; // Discharge Documentation
        const TYPE_CONSULTATION = '11488-4'; // Consultation
        const TYPE_HISTORY_AND_PHYSICAL = '34117-2'; // History & Physical
        const TYPE_PROGRESS_NOTE = '11506-3'; // Progress Note
        const TYPE_PROCEDURE_NOTE = '28570-0'; // Procedure Note
        const TYPE_EMERGENCY_DEPARTMENT_NOTE = '34111-5'; // Emergency Department Note
        const TYPE_PATIENT_INSTRUCTIONS = '69730-0'; // Patient Instructions
        const TYPE_NURSE_NOTE = '34746-8'; // Nurse Note

        public function __construct($params)
        {
            parent::__construct($params);
            $this->attachments = $this->getAttachments();
        }

        /* public static function getSearchUrl($params=array())
        {
            $url = parent::getSearchUrl($params);
            $STU3_url = preg_replace("/(.+\/)DSTU2(\/.+)/", '$1STU3$2', $url);
            return $STU3_url;
        } */

        /**
         * attribute that contains the date for the resource
         *
         * @var string
         */
        protected static $dateAttribute = 'indexed';

        public function getStatus()
        {
            return $this->status;
        }

        public function getLabel()
        {
            $type = $this->type;
            $text = $type->text;
            return $text;
        }

        public function getContents()
        {
            $contents = $this->content;
            return $contents;
        }

        protected function getAttachments()
        {
            $contents = $this->getContents();
            $attachments = array();
            foreach ($contents as $content) {
                $attachment = $content->attachment;
                $attachments[] = new \FhirResourceDocumentReference\Attachment($attachment);
            }
            return $attachments;
        }

        public function getData()
        {
            $data = array(
                'label' => $this->getLabel(),
                // 'status' => $this->getStatus(),
                'content' => $this->getContents(),
                'date' => $this->getFormattedDate(),
                'attachments' => $this->attachments,
            );
            return $data;
        }
    }
}

namespace FhirResourceDocumentReference {


    /**
     * @property string $url
     */
    class Attachment extends \FhirResource
    {
        private $binary_data;
        /**
         * path to the default stylesheet path
         * the stylesheet can transform a ClinicalDocument to HTML
         *
         * @var string
         */
        private $default_stylesheetPath = APP_PATH_DOCROOT.'Resources/misc/clinical_documents/'.'CDA.xsl';

        public function getData()
        {
            $data = array(
                // 'binary_data' => $this->binary_data,
                'download_url' => $this->getDownloadUrl(),
                'text' => $this->parseText($this->binary_data),
            );
            return $data;
        }

        public function getDownloadUrl()
        {
            $url = $this->url;
            $url_parts = explode('/', $url);
            $document_ID = end($url_parts);
            return sprintf("/download?document_id=%s", $document_ID);
        }

        public function setBinaryData($binary_data)
        {
            $this->binary_data = $binary_data;
        }

        public function stripHTML()
        {
            // https://regex101.com/r/78S1wx/1
        }

        private function toHTML($clinicalDocumentXML)
        {
            $html = array();
            $title = sprintf("<h3>%s</h3>", $clinicalDocumentXML->title);
            $html[] = $title;
            $components = $clinicalDocumentXML->component->structuredBody->component;
            foreach ($components as $component) {
                $section = $component->section;
                $title = sprintf("<h4>%s</h4>", $section->title);
                $html[] = $title;
                $textChildren = $section->text->children();
                foreach($textChildren as $textXML)
                {
                    $html[] = $textXML->asXML();
                }
                $html[] = sprintf("<p>%s</p>", str_repeat("-",50)).PHP_EOL;
            }
            return implode(PHP_EOL, $html);
        }

        /**
         * use a XSLT stylesheet to transform an XML string
         *
         * @param string $stylesheetPath path to XSLT document
         * @return void
         */
        public function transformXML($stylesheetPath)
        {
            $xmlString = $this->binary_data;
            $proc = new \XsltProcessor;
            $clinicalDocumentStylesheet = \DOMDocument::load($stylesheetPath);
            $proc->importStylesheet($clinicalDocumentStylesheet);  
            // echo $proc->transformToXML(DOMDocument::load("script.xml"));
            $domDocument = \DOMDocument::loadXML($xmlString);
            /* $domDocument = \DOMDocument::loadHTML($string);
            $body = $domDocument->getElementsByTagName('body'); */
            $result = $proc->transformToXML($domDocument);
            // file_put_contents(EDOC_PATH.'result.html', $result); //save HTML document locally
            return $result;
        }

        public function parseText($html_string)
        {
            if(!class_exists('\Soundasleep\Html2Text'))
            {
                require_once(APP_PATH_DOCROOT.'../custom_libraries/vendor/autoload.php');
            }
            $options = array(
                'ignore_errors' => true,
                // other options go here
            );
            $text = \Soundasleep\Html2Text::convert($html_string, $options);
            return $text;
        }

        /**
         * Undocumented function
         *
         * @param object|array $object
         * @param array $flattened
         * @param array $path
         * @param string $path_separator character that separates the elements of the path
         * @return array
         */
        private function flatten_object($object, $flattened=array(), $path=array(), $path_separator = ':')
        {
            foreach($object as $key => $value)
            {
                $path[] = $key;
                if(is_array($value) || is_object($value))
                {
                    $flattened = $this->flatten_object($value, $flattened, $path);
                    array_pop($path);
                    continue;
                }
                $string_path = implode($path_separator, $path);
                $flattened[$string_path] = $value; // the complete path
                // $flattened[$key] = $value; // just the final key
                array_pop($path);
            }
            return $flattened;
        }


        public function download($access_token)
        {
            \FileManager::forceDownload('file', $this->url);
        }

    }
}