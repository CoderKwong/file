<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/
use Vanderbilt\REDCap\Classes\NamespaceExample\Test;


// Config for project-level or non-project pages
if (isset($_GET['pid'])) {
	require_once dirname(__FILE__) . "/Config/init_project.php";
} else {
	require_once dirname(__FILE__) . "/Config/init_global.php";
}
$objHtmlPage = new HtmlPage();
$objHtmlPage->addStylesheet("home.css", 'screen,print');
$objHtmlPage->PrintHeader();

$namespace_test = new Test();

$namespace_test->hello();
?>

<?php
$objHtmlPage->PrintFooter();