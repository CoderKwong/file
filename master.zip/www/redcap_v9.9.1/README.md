# REDCap #

This is the Git repo of [REDCap software](https://projectredcap.org/). The source code is available to all REDCap consortium partner institutions who have accepted the REDCap license agreement with Vanderbilt University.
