<?php
	global $log_all_errors;
	$log_all_errors = FALSE;
	$hostname = "db";
	$db       = "redcap";
	$username = "redcap";
	$password = "redcap123";
	$salt     = "12345678";
	